<?php
//pega o numero do pedido
 $numero = $_GET['num'];


include "../../config/database/conexao2.php"; //Conexão
// Pega os dados da loja
$sql = "SELECT * FROM wp_options WHERE option_name = 'wpo_wcpdf_settings_general'";
$res_dados_loja = mysqli_query($conexao,$sql);
while($row = mysqli_fetch_assoc($res_dados_loja)) {
    $dados = unserialize( $row['option_value']);
}
//$dados = unserialize( base64_decode( $dados ) );

print_r( $dados );

echo "<hr>";

echo( $dados['shop_name']['default'] );

echo "<hr>";
$end =  $dados['shop_address']['default'];
$arrEnd = explode('CEP',$end);

echo ( '<div style="width:18%">'.$arrEnd[0].'<br>CEP'.$arrEnd[1].'</div>' );

echo "<hr>";

echo( $dados['footer']['default'] );

echo "<hr>";

echo( $dados['extra_1']['default'] );



include "../../config/database/conexao.php"; //Conexão
?>

<div class="card">
    <div class="card-header ui-sortable-handle" style="cursor: pointer;">
        <h2>Fatura do Pedido de Venda</h2>
        <div class="card-tools" style="margin-right: 10px;">
            <ul class="nav nav-pills ml-auto">

                <li class="nav-item">
                    <form action="pdf-gen.php" method="POST">
                        <input type="hidden" name="num" value="<? echo $numero; ?>">
                        <button title='Criar PDF' name='btn_pdf' type='submit' class='btn btn-success float-right'><i class='fas fa-save'></i><span class="btn-resp"> Salvar</span></button>
                    </form>
                </li>
            </ul>
        </div>
    </div>
    <div class="card-body table-responsive">
        <table id="itens_do_pedido" class="display responsive hover compact nowrap">
            <thead>
                <tr>

                    <th></th>
                    <th>Produto</th>
                    <th>Unid.</th>
                    <th>Valor Unit.</th>
                    <th>Qtde</th>
                    <th>Desconto</th>
                    <th>Subtotal</th>



                </tr>
            </thead>
            <tbody>

                <?php                             
                                    //SELECT Número, Data, Situação, Cliente, Total FROM `vendas`
                                   

                                    $query = "SELECT 
                                    I.id,
                                    F.numero_pedido as NF,
                                    P.id as IdProduto,
                                    P.descricao as Produto,
                                    P.unidade as Unidade,
                                    P.preco as Preço,
                                    I.quantidade as Quantidade,
                                    I.desconto as Desconto,
                                    (P.preco * I.quantidade) - I.desconto as Subtotal,
                                    (P.preco * I.quantidade) as TotalItens
                                    FROM tbl_pedidos_venda as F
                                    INNER JOIN tbl_itens_pedido as I
                                    ON F.numero_pedido = I.id_pedido
                                    INNER JOIN tbl_produtos as P
                                    ON I.id_produto = P.id
                                    WHERE I.id_pedido = '$numero'";
                                
                                
                                    $result = mysqli_query($conexao,$query);
                                    $clinha=0;

                                    //VARIAVEIS READONLY
                                    // SESSAO TOTAIS
                                    $soma_qtdes = 0;
                                    $t_desc_itens = 0;
                                    $t_valor_itens = 0;
                                    $t_subtotal = 0;

                                
                                    while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) : 
                                        $clinha++;
                                ?>

                <tr role="row" class="even dpedido" data-id="<?php echo $row['id']; ?>">

                    <td class="clinha"><span class="badge badge-dark">
                            <? echo $clinha; ?>
                        </span></td>

                    <td class="dpedidoitem"><?php echo $row['Produto']; ?> </td>
                    <td class="dpedidoitem"><?php echo $row['Unidade']; ?> </td>
                    <td class="dpedidoitem"><?php echo wc_price($row['Preço']); ?> </td>
                    <td class="dpedidoitem">
                        <?php echo $row['Quantidade']; $soma_qtdes+=(float)$row['Quantidade']; ?>
                    </td>
                    <td class="dpedidoitem"><?php echo wc_price($row['Desconto']); ?> </td>
                    <td class="dpedidoitem"><?php echo wc_price($row['Subtotal']); ?> </td>






                </tr>
                <?php endwhile;  ?>
            </tbody>

        </table>


    </div>
</div>
<!-- /.card-body -->