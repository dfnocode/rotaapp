function calculaPedido(soma) {
    alert(soma);
}

$(document).ready(function() {

    /* 


        $("#descAdicional").focus(function() {
            var tComs = $("#descAdicional").val();
            //var pComs = parseFloat($("#descAdicional").val() * 10);
            var uptdComs = tComs;
            $("#descAdicional").val(uptdComs);
        });

        $("#descAdicional").keyup(function() {
            //$("#val_produto").css("background-color", "pink");
            var tComs = parseFloat($("#soma-final").val());
            var pComs = parseFloat($("#descAdicional").val() * 10);
            var uptdComs = tComs;
            $("#soma-final").val(uptdComs);

        });

        $("#descAdicional").keydown(function() {
            //$("#val_produto").css("background-color", "yellow");
            var tComs = parseFloat($("#soma-final").val());
            var pComs = parseFloat($("#descAdicional").val() * 10);
            var uptdComs = tComs;
            $("#soma-final").val(uptdComs);

        });

        $("#descAdicional").keypress(function() {
            var tComs = parseFloat($("#soma-final").val());
            var pComs = parseFloat($("#descAdicional").val() * 10);
            var uptdComs = tComs;
            $("#soma-final").val(uptdComs);

        }); */
});