-- 
-- Editor SQL for DB table tbl_pedidos_venda
-- Created by http://editor.datatables.net/generator
-- 

CREATE TABLE IF NOT EXISTS `tbl_pedidos_venda` (
	`id` int(10) NOT NULL auto_increment,
	`numero_pedido` varchar(255),
	`data_registro` datetime,
	`id_vendedor` varchar(255),
	`id_cliente` numeric(9,2),
	`desconto` numeric(9,2),
	`observacoes` text,
	`situacao` varchar(255),
	`soma_itens` numeric(9,2),
	`subtotal` numeric(9,2),
	`frete` numeric(9,2),
	`valor_total` numeric(9,2),
	PRIMARY KEY( `id` )
);

