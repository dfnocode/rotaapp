-- 
-- Editor SQL for DB table tbl_itens_pedido
-- Created by http://editor.datatables.net/generator
-- 

CREATE TABLE IF NOT EXISTS `tbl_itens_pedido` (
	`id` int(10) NOT NULL auto_increment,
	`id_pedido` varchar(255),
	`id_produto` numeric(9,2),
	`valor_unit` numeric(9,2),
	`unidade` varchar(255),
	`quantidade` varchar(255),
	`valor` numeric(9,2),
	PRIMARY KEY( `id` )
);