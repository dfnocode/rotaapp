<?php

/*
 * Editor server script for DB table tbl_pedidos_venda
 * Created by http://editor.datatables.net/generator
 */

// DataTables PHP library and database connection
include( "lib/DataTables.php" );

// Alias Editor classes so they are easy to use
use
	DataTables\Editor,
	DataTables\Editor\Field,
	DataTables\Editor\Format,
	DataTables\Editor\Mjoin,
	DataTables\Editor\Options,
	DataTables\Editor\Upload,
	DataTables\Editor\Validate,
	DataTables\Editor\ValidateOptions;

// The following statement can be removed after the first run (i.e. the database
// table has been created). It is a good idea to do this to help improve
// performance.
$db->sql( "CREATE TABLE IF NOT EXISTS `tbl_pedidos_venda` (
	`id` int(10) NOT NULL auto_increment,
	`numero_pedido` varchar(255),
	`data_registro` datetime,
	`vendedor` int(11),
	`id_cliente` int(11),
	`desconto` numeric(9,2),
	`observacoes` text,
	`situacao` varchar(255),
	`soma_itens` numeric(9,2),
	`subtotal` numeric(9,2),
	`frete` numeric(9,2),
	`valor_total` numeric(9,2),
	PRIMARY KEY( `id` )
);" );

// Build our Editor instance and process the data coming from _POST
Editor::inst( $db, 'tbl_pedidos_venda', 'id' )
	->fields(
		Field::inst( 'numero_pedido' ),
		Field::inst( 'data_registro' )
			->validator( Validate::dateFormat( 'd/m/y H:i' ) )
			->getFormatter( Format::datetime( 'Y-m-d H:i:s', 'd/m/y H:i' ) )
			->setFormatter( Format::datetime( 'd/m/y H:i', 'Y-m-d H:i:s' ) ),
		Field::inst( 'id_vendedor' )
		->options( Options::inst()
			->table( 'vendedores' )
			->value( 'vendedores.id' )
			->label( 'vendedores.nome' )			
	),
		Field::inst( 'id_cliente' )
		->options( Options::inst()
		->table( 'clientes' )
		->value( 'clientes.id' )
		->label( 'clientes.nome' )		
),
		Field::inst( 'desconto' )
			->validator( Validate::numeric() ),
		Field::inst( 'observacoes' ),
		Field::inst( 'situacao' ),
		Field::inst( 'soma_itens' ),
		Field::inst( 'subtotal' ),
		Field::inst( 'frete' ),
		Field::inst( 'valor_total' )
	)
	
	->process( $_POST )
	->json();
