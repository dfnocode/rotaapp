$(document).ready(function() {
    /// Quando usuário clicar em salvar será feito todos os passo abaixo
    $('#salvar').click(function() {

        var dados = $('#pesquisaPessoa').serialize();

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: 'salvar.php',
            async: true,
            data: dados,
            success: function(response) {
                location.reload();
            }
        });

        return false;
    });

});


$(document).ready(function() {

    $("#cadastroUser").submit(function(e) {
        e.preventDefault();
        $.ajax({
            url: "../../config/functions/insertUser.php",
            method: "post",
            data: $("form").serialize(),
            dataType: "text",
            success: function(strMessage) {
                $("#message").text(strMessage);
                if (strMessage == 'sucesso') {
                    Swal.fire(
                        'Registro Inserido com Sucesso!',
                        'Clique para retornar',
                        'success'
                    )
                    $('#cadastroUser').trigger("reset");
                } else if (strMessage == 'update') {
                    Swal.fire(
                        'Registro Atualizado com Sucesso!',
                        'Clique para retornar',
                        'success'
                    )
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: strMessage,

                    });
                }


            }
        });

    });
});