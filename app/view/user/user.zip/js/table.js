var table = document.getElementById('user');
for (var i = 1; i < table.rows.length; i++) {
    table.rows[i].onclick = function() {

       document.getElementById("id_user").value = this.cells[0].innerHTML;
       document.getElementById("edit_nome").value = this.cells[1].innerHTML;
       document.getElementById("edit_email").value = this.cells[2].innerHTML;
        
    }
};