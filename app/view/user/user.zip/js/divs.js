function OpenCadastro() {
    var x = document.getElementById("divCadastros");
    var y = document.getElementById("divPesquisar");
    var z = document.getElementById("result");

    if (x.style.display === "none") {
        x.style.display = "block";

    } else {
        x.style.display = "none";
        y.style.display = "none";
        z.style.display = "none";

    }


}